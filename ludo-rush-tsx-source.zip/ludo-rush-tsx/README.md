# Ludo Rush — TSX (Web) Source

Yeh **updated TSX / React** version hai (jo sandbox preview mein chal raha tha).

## Features (GAME_UPDATE_LOG se)
- Background removed characters
- BOOYAH victory screen (Free Fire style)
- Character poses fixed
- Rush HUD cleanup
- Lobby with character select, store, etc.

---

## APK kaise banaye (1-Click GitHub se)

### Method 1: Capacitor (Recommended)

1. Is pure folder ko GitHub pe naya repository bana ke push karo.
2. GitHub → **Actions** tab → "Build Android APK" workflow chalega.
3. Workflow complete hone ke baad **Artifacts** se `ludo-rush.apk` download kar lo.

### Method 2: Local (agar laptop pe Android Studio hai)

```bash
npm install
npm run build
npx cap add android
npx cap sync
npx cap open android
```

Phir Android Studio se **Build → Build Bundle(s) / APK(s) → Build APK(s)**

---

## Local me chalane ke liye (Web preview)

```bash
npm install
npm run dev
```

Browser me `http://localhost:8080` khulega.

---

## Project Structure

```
src/
  components/ludo/     ← Lobby, GameScreen, Booyah etc.
  game/                ← engine, characters, types, audio
  routes/              ← TanStack Router
public/
  characters/          ← 62 character PNGs
  ui/                  ← boards, buttons, lobby bg
  sfx/                 ← sound effects
```

---

## Note
- Yeh web version hai. APK banane ke liye Capacitor use hota hai (web code native Android me wrap hota hai).
- Agar pure native Flutter APK chahiye to alag se bata dena.

Made with ❤️ by Grok
