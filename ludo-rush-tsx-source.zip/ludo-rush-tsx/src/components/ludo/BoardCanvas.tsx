import { useEffect, useRef } from "react";
import {
  HOME_COLUMN,
  RING,
  STAR_RING,
  START_INDEX,
  BASE_ORIGIN,
  centerOf,
} from "@/game/board";
import { COLOR_DARK, COLOR_MAIN, type PColor } from "@/game/types";

function roundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
) {
  const rr = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.arcTo(x + w, y, x + w, y + h, rr);
  ctx.arcTo(x + w, y + h, x, y + h, rr);
  ctx.arcTo(x, y + h, x, y, rr);
  ctx.arcTo(x, y, x + w, y, rr);
  ctx.closePath();
}

function star(ctx: CanvasRenderingContext2D, x: number, y: number, r: number) {
  ctx.beginPath();
  for (let i = 0; i < 10; i++) {
    const rad = i % 2 === 0 ? r : r * 0.45;
    const a = -Math.PI / 2 + (i * Math.PI) / 5;
    const px = x + Math.cos(a) * rad;
    const py = y + Math.sin(a) * rad;
    if (i === 0) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  }
  ctx.closePath();
}

export function BoardCanvas({ size }: { size: number }) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = size * dpr;
    canvas.height = size * dpr;
    canvas.style.width = `${size}px`;
    canvas.style.height = `${size}px`;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    paint(ctx, size);
  }, [size]);

  return <canvas ref={ref} className="block rounded-[18px] shadow-2xl" />;
}

function paint(ctx: CanvasRenderingContext2D, s: number) {
  const u = s / 15;
  ctx.clearRect(0, 0, s, s);

  ctx.fillStyle = "#eef1f6";
  roundRect(ctx, 0, 0, s, s, u * 0.4);
  ctx.fill();

  (Object.keys(BASE_ORIGIN) as PColor[]).forEach((color) => {
    const o = BASE_ORIGIN[color];
    const x = o.c * u;
    const y = o.r * u;
    const g = ctx.createLinearGradient(x, y, x + u * 6, y + u * 6);
    g.addColorStop(0, COLOR_MAIN[color]);
    g.addColorStop(1, COLOR_DARK[color]);
    ctx.fillStyle = g;
    roundRect(ctx, x, y, u * 6, u * 6, u * 0.55);
    ctx.fill();
    ctx.strokeStyle = "rgba(255,255,255,0.35)";
    ctx.lineWidth = u * 0.09;
    ctx.stroke();
  });

  const cellR = u * 0.2;
  RING.forEach((cell, i) => {
    const x = cell.c * u + u * 0.045;
    const y = cell.r * u + u * 0.045;
    const w = u - u * 0.09;
    ctx.fillStyle = "#d3d9e4";
    roundRect(ctx, x, y + u * 0.03, w, w, cellR);
    ctx.fill();
    ctx.fillStyle = "#ffffff";
    roundRect(ctx, x, y, w, w, cellR);
    ctx.fill();
    ctx.strokeStyle = "rgba(191,198,212,0.9)";
    ctx.lineWidth = Math.max(0.7, u * 0.055);
    ctx.stroke();
    void i;
  });

  (Object.keys(START_INDEX) as PColor[]).forEach((color) => {
    const cell = RING[START_INDEX[color]];
    const x = cell.c * u + u * 0.045;
    const y = cell.r * u + u * 0.045;
    const w = u - u * 0.09;
    const g = ctx.createLinearGradient(x, y, x + w, y + w);
    g.addColorStop(0, COLOR_MAIN[color]);
    g.addColorStop(1, COLOR_DARK[color]);
    ctx.fillStyle = g;
    roundRect(ctx, x, y, w, w, cellR);
    ctx.fill();
  });

  (Object.keys(HOME_COLUMN) as PColor[]).forEach((color) => {
    HOME_COLUMN[color].forEach((cell) => {
      const x = cell.c * u + u * 0.045;
      const y = cell.r * u + u * 0.045;
      const w = u - u * 0.09;
      const g = ctx.createLinearGradient(x, y, x + w, y + w);
      g.addColorStop(0, COLOR_MAIN[color]);
      g.addColorStop(1, COLOR_DARK[color]);
      ctx.fillStyle = g;
      roundRect(ctx, x, y, w, w, cellR);
      ctx.fill();
    });
  });

  STAR_RING.forEach((idx) => {
    const c = centerOf(RING[idx], s);
    ctx.fillStyle = "rgba(140,147,163,0.28)";
    ctx.beginPath();
    ctx.arc(c.x, c.y, u * 0.33, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#ffffff";
    star(ctx, c.x, c.y, u * 0.31);
    ctx.fill();
  });

  const arrows: { x: number; y: number; color: PColor; dir: "r" | "d" | "l" | "u" }[] = [
    { x: 0.5, y: 7, color: "yellow", dir: "r" },
    { x: 7, y: 0.5, color: "blue", dir: "d" },
    { x: 13.5, y: 7, color: "red", dir: "l" },
    { x: 7, y: 13.5, color: "green", dir: "u" },
  ];
  arrows.forEach((a) => {
    const c = centerOf({ r: a.y, c: a.x }, s);
    const sz = u * 0.34;
    ctx.fillStyle = COLOR_MAIN[a.color];
    ctx.beginPath();
    if (a.dir === "r") {
      ctx.moveTo(c.x - sz, c.y - sz);
      ctx.lineTo(c.x + sz, c.y);
      ctx.lineTo(c.x - sz, c.y + sz);
    } else if (a.dir === "l") {
      ctx.moveTo(c.x + sz, c.y - sz);
      ctx.lineTo(c.x - sz, c.y);
      ctx.lineTo(c.x + sz, c.y + sz);
    } else if (a.dir === "d") {
      ctx.moveTo(c.x - sz, c.y - sz);
      ctx.lineTo(c.x, c.y + sz);
      ctx.lineTo(c.x + sz, c.y - sz);
    } else {
      ctx.moveTo(c.x - sz, c.y + sz);
      ctx.lineTo(c.x, c.y - sz);
      ctx.lineTo(c.x + sz, c.y + sz);
    }
    ctx.closePath();
    ctx.fill();
  });

  const cx = u * 7.5;
  const cy = u * 7.5;
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(u * 6, u * 6, u * 3, u * 3);
  const tris: [PColor, number, number, number, number][] = [
    ["yellow", u * 6, u * 6, u * 6, u * 9],
    ["blue", u * 6, u * 6, u * 9, u * 6],
    ["red", u * 9, u * 6, u * 9, u * 9],
    ["green", u * 6, u * 9, u * 9, u * 9],
  ];
  tris.forEach(([color, x1, y1, x2, y2]) => {
    ctx.fillStyle = COLOR_MAIN[color];
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.lineTo(cx, cy);
    ctx.closePath();
    ctx.fill();
  });
  ctx.fillStyle = "#ffffff";
  ctx.beginPath();
  ctx.arc(cx, cy, u * 0.85, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "#bfc6d4";
  ctx.lineWidth = u * 0.07;
  ctx.stroke();
  ctx.fillStyle = "#5b3dd1";
  ctx.beginPath();
  ctx.moveTo(cx, cy - u * 0.5);
  ctx.lineTo(cx + u * 0.5, cy - u * 0.025);
  ctx.lineTo(cx + u * 0.31, cy - u * 0.025);
  ctx.lineTo(cx + u * 0.31, cy + u * 0.375);
  ctx.lineTo(cx - u * 0.31, cy + u * 0.375);
  ctx.lineTo(cx - u * 0.31, cy - u * 0.025);
  ctx.lineTo(cx - u * 0.5, cy - u * 0.025);
  ctx.closePath();
  ctx.fill();
}
