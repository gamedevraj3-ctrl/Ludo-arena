import { useState } from "react";
import {
  CalendarPlus,
  Coins,
  Download,
  Gem,
  Gift,
  Mail,
  Menu,
  Play,
  Plus,
  Settings,
  Skull,
  Trophy,
  Volume2,
  VolumeX,
} from "lucide-react";
import { assetFor, resolveName } from "@/game/characters";
import { Sfx } from "@/game/audio";
import type { GameConfig, GameMode, MatchMode } from "@/game/types";
import { defaultConfig } from "@/game/types";
import { CharacterBook } from "./CharacterBook";
import { StorePanel } from "./StorePanel";

type Overlay =
  | "none"
  | "character"
  | "store"
  | "luck"
  | "vault"
  | "collection"
  | "weapon"
  | "mail"
  | "events"
  | "rank"
  | "start"
  | "settings";

export function Lobby({
  onStart,
}: {
  onStart: (cfg: GameConfig) => void;
  onPreviewBooyah?: () => void;
}) {
  const [name, setName] = useState(() => localStorage.getItem("ludo_name") || "You");
  const [character, setCharacter] = useState(() =>
    resolveName(localStorage.getItem("ludo_character") || "Kassie"),
  );
  const [overlay, setOverlay] = useState<Overlay>("none");
  const [sound, setSound] = useState(() => Sfx.enabled);
  const [matchMode, setMatchMode] = useState<MatchMode>("rush");
  const [gameMode, setGameMode] = useState<GameMode>("bots");
  const [players, setPlayers] = useState<2 | 3 | 4>(4);
  const [rushMins, setRushMins] = useState(6);
  const gold = 1000;
  const gems = 10;

  function persistName(v: string) {
    const next = v.slice(0, 14);
    setName(next);
    localStorage.setItem("ludo_name", next);
  }
  function pickChar(n: string) {
    const next = resolveName(n);
    setCharacter(next);
    localStorage.setItem("ludo_character", next);
  }
  function open(next: Overlay) {
    Sfx.tap();
    setOverlay(next);
  }
  function play() {
    Sfx.tap();
    onStart({
      ...defaultConfig,
      mode: gameMode,
      matchMode,
      playerCount: players,
      matchSeconds: matchMode === "rush" ? rushMins * 60 : 0,
      myName: name.trim() || "You",
      myCharacter: character,
    });
  }

  const sheetOpen =
    overlay === "character" ||
    overlay === "store" ||
    overlay === "luck" ||
    overlay === "vault" ||
    overlay === "collection" ||
    overlay === "weapon";

  return (
    <div className="hub" style={{ backgroundImage: "url(/ui/lobby_camp.jpg)" }}>
      {!sheetOpen && (
        <>
          <button type="button" className="hub-hero-hit" onClick={() => open("character")} aria-label="Choose character">
            <img className="hub-hero" src={assetFor(character)} alt="" />
          </button>

          <header className="hub-top">
            <button type="button" className="hub-id" onClick={() => open("character")}>
              <img src={assetFor(character)} alt="" />
              <div>
                <input
                  value={name}
                  maxLength={14}
                  onClick={(e) => e.stopPropagation()}
                  onChange={(e) => persistName(e.target.value)}
                  aria-label="Your name"
                />
                <p>Lv. 12</p>
              </div>
              <span className="hub-rank">A</span>
            </button>
            <div className="hub-wallet">
              <span>
                <Coins className="h-3.5 w-3.5" /> {gold.toLocaleString()}
              </span>
              <span>
                <Gem className="h-3.5 w-3.5" /> {gems}
              </span>
            </div>
            <div className="hub-brand">LUDO RUSH</div>
            <div className="hub-top-right">
              <button type="button" className="hub-ico" onClick={() => open("character")} aria-label="Characters">
                <Skull className="h-4 w-4" />
              </button>
              <button type="button" className="hub-ico" aria-label="Download">
                <Download className="h-4 w-4" />
              </button>
              <button type="button" className="hub-ico" onClick={() => open("mail")} aria-label="Mail">
                <Mail className="h-4 w-4" />
              </button>
              <button type="button" className="hub-ico" onClick={() => open("settings")} aria-label="Settings">
                <Settings className="h-4 w-4" />
              </button>
              <button
                type="button"
                className="hub-ico"
                onClick={() => {
                  const next = !sound;
                  Sfx.setEnabled(next);
                  setSound(next);
                  if (next) Sfx.tap();
                }}
                aria-label={sound ? "Sound on" : "Sound off"}
              >
                {sound ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
              </button>
              <button type="button" className="hub-ico" aria-label="Menu">
                <Menu className="h-4 w-4" />
              </button>
            </div>
          </header>

          <div className="hub-banner">
            <div className="hub-banner-main">
              <p>LUDO RUSH</p>
              <span>SUBSCRIBE</span>
            </div>
          </div>

          <aside className="hub-rail">
            <button type="button" className="hub-rail-btn" onClick={() => open("events")} aria-label="Events">
              <CalendarPlus className="h-5 w-5" />
            </button>
            <button type="button" className="hub-rail-btn" onClick={() => open("rank")} aria-label="Rank">
              <Trophy className="h-5 w-5" />
            </button>
            <button type="button" className="hub-rail-btn" onClick={() => open("luck")} aria-label="Rewards">
              <Gift className="h-5 w-5" />
            </button>
            <button type="button" className="hub-rail-btn" onClick={() => open("store")} aria-label="Plus">
              <Plus className="h-5 w-5" />
            </button>
          </aside>

          <button type="button" className="hub-mode" onClick={() => open("start")}>
            <div>
              <p>{matchMode === "rush" ? "Rush Match" : "Classic"}</p>
              <span>
                {gameMode === "bots" ? "VS Bots" : "Pass & Play"} · {players}P
                {matchMode === "rush" ? ` · ${rushMins} min` : ""}
              </span>
            </div>
            <img src={assetFor(character)} alt="" />
          </button>

          <button type="button" className="hub-start" onClick={play}>
            START
            <Play className="h-5 w-5 fill-current" />
          </button>
        </>
      )}

      {overlay === "character" && (
        <CharacterBook selected={character} onSelect={pickChar} onClose={() => setOverlay("none")} />
      )}
      {overlay === "store" && <StorePanel onClose={() => setOverlay("none")} />}
      {overlay === "luck" && (
        <EmptySheet title="LUCK ROYALE" note="No crates available right now." onClose={() => setOverlay("none")} />
      )}
      {overlay === "vault" && (
        <EmptySheet title="VAULT" note="No items stored yet." onClose={() => setOverlay("none")} />
      )}
      {overlay === "collection" && (
        <EmptySheet title="COLLECTION" note="No collection items yet." onClose={() => setOverlay("none")} />
      )}
      {overlay === "weapon" && (
        <EmptySheet title="WEAPON" note="No weapons in this mode." onClose={() => setOverlay("none")} />
      )}
      {(overlay === "mail" || overlay === "events" || overlay === "rank") && (
        <div className="ff-modal-bg" onClick={() => setOverlay("none")}>
          <div className="ff-modal" onClick={(e) => e.stopPropagation()}>
            <h2>{overlay === "mail" ? "Mail" : overlay === "events" ? "Events" : "Rank"}</h2>
            <p>Nothing new here yet.</p>
            <button type="button" className="ff-ghost" onClick={() => setOverlay("none")}>
              Close
            </button>
          </div>
        </div>
      )}
      {overlay === "settings" && (
        <div className="ff-modal-bg" onClick={() => setOverlay("none")}>
          <div className="ff-modal" onClick={(e) => e.stopPropagation()}>
            <h2>Settings</h2>
            <p>Sound, speed and rules live on the match screen once you hit START.</p>
            <button type="button" className="ff-ghost" onClick={() => setOverlay("none")}>
              Close
            </button>
          </div>
        </div>
      )}
      {overlay === "start" && (
        <div className="ff-modal-bg" onClick={() => setOverlay("none")}>
          <div className="ff-modal ff-start-modal" onClick={(e) => e.stopPropagation()}>
            <h2>Match Setup</h2>
            <p className="ff-label">MODE</p>
            <div className="ff-seg">
              <button type="button" className={matchMode === "rush" ? "is-on" : ""} onClick={() => setMatchMode("rush")}>
                Rush
              </button>
              <button
                type="button"
                className={matchMode === "classic" ? "is-on" : ""}
                onClick={() => setMatchMode("classic")}
              >
                Classic
              </button>
            </div>
            {matchMode === "rush" && (
              <>
                <p className="ff-label">MATCH TIME</p>
                <div className="ff-seg">
                  <button type="button" className={rushMins === 4 ? "is-on" : ""} onClick={() => setRushMins(4)}>
                    4 min
                  </button>
                  <button type="button" className={rushMins === 6 ? "is-on" : ""} onClick={() => setRushMins(6)}>
                    6 min
                  </button>
                </div>
                <p className="ff-label">CUSTOM · {rushMins} MIN</p>
                <input
                  className="ff-seek"
                  type="range"
                  min={1}
                  max={15}
                  step={1}
                  value={rushMins}
                  aria-label="Custom rush time"
                  onChange={(e) => setRushMins(Number(e.target.value))}
                />
                <div className="ff-seek-ends">
                  <span>1 min</span>
                  <span>15 min</span>
                </div>
              </>
            )}
            <p className="ff-label">PLAYERS</p>
            <div className="ff-seg">
              <button type="button" className={gameMode === "bots" ? "is-on" : ""} onClick={() => setGameMode("bots")}>
                VS Bots
              </button>
              <button
                type="button"
                className={gameMode === "passAndPlay" ? "is-on" : ""}
                onClick={() => setGameMode("passAndPlay")}
              >
                Play & Pass
              </button>
            </div>
            <div className="ff-seg">
              {([2, 3, 4] as const).map((n) => (
                <button key={n} type="button" className={players === n ? "is-on" : ""} onClick={() => setPlayers(n)}>
                  {n}
                </button>
              ))}
            </div>
            <button type="button" className="hub-start hub-start-inline" onClick={play}>
              START
              <Play className="h-5 w-5 fill-current" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function EmptySheet({ title, note, onClose }: { title: string; note: string; onClose: () => void }) {
  return (
    <div className="ff-sheet">
      <header className="ff-sheet-head">
        <button type="button" className="ff-icon-btn" onClick={onClose} aria-label="Close">
          ←
        </button>
        <h1 className="ff-sheet-title">{title}</h1>
      </header>
      <div className="ff-store-empty">
        <h2>No items in {title}</h2>
        <p>{note}</p>
      </div>
    </div>
  );
}
