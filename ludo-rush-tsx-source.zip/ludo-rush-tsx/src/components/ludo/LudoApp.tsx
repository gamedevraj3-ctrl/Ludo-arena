import { useCallback, useEffect, useState } from "react";
import { Lobby } from "./Lobby";
import { GameView } from "./GameScreen";
import { BooyahScreen, demoRows } from "./Booyah";
import { LandscapeFrame } from "./Landscape";
import { Sfx } from "@/game/audio";
import type { LudoEngine } from "@/game/engine";
import type { GameConfig, ScoreRow } from "@/game/types";
import { defaultConfig } from "@/game/types";

type Screen = "splash" | "lobby" | "game" | "booyah";

export function LudoApp() {
  const [screen, setScreen] = useState<Screen>("splash");
  const [progress, setProgress] = useState(0);
  const [config, setConfig] = useState<GameConfig>(defaultConfig);
  const [rows, setRows] = useState<ScoreRow[]>(demoRows());

  useEffect(() => {
    Sfx.init();
    const steps = [10, 25, 50, 65, 80, 92, 100];
    let i = 0;
    const id = window.setInterval(() => {
      setProgress(steps[i] ?? 100);
      i++;
      if (i >= steps.length) {
        window.clearInterval(id);
        window.setTimeout(() => setScreen("lobby"), 280);
      }
    }, 180);
    return () => window.clearInterval(id);
  }, []);

  const onFinish = useCallback((engine: LudoEngine) => {
    setRows(engine.results());
    setScreen("booyah");
  }, []);

  let body;
  if (screen === "splash") {
    body = (
      <div
        className="ff-lobby flex h-full flex-col items-center justify-end px-8 pb-8"
        style={{ backgroundImage: "url(/ui/lobby_camp.jpg)" }}
        onClick={() => setScreen("lobby")}
        onKeyDown={() => setScreen("lobby")}
        role="button"
        tabIndex={0}
      >
        <div className="ff-lobby-dim" />
        <div className="relative z-10 mb-auto mt-10 text-center">
          <div className="booyah-title text-6xl">LUDO RUSH</div>
          <p className="mt-2 text-xs font-black tracking-[0.35em] text-muted">RESOURCE LOADING, PLEASE WAIT</p>
        </div>
        <div className="relative z-10 h-2 w-full max-w-xl overflow-hidden rounded-full bg-black/40">
          <div
            className="h-full rounded-full bg-linear-to-r from-gold to-[#ff8f00] transition-all duration-300"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>
    );
  } else if (screen === "lobby") {
    body = (
      <Lobby
        onStart={(cfg) => {
          setConfig(cfg);
          setScreen("game");
        }}
      />
    );
  } else if (screen === "booyah") {
    body = (
      <BooyahScreen
        rows={rows}
        config={config}
        onLobby={() => setScreen("lobby")}
        onAgain={() => setScreen("game")}
      />
    );
  } else {
    body = (
      <GameView
        config={config}
        onFinish={onFinish}
        onLeave={() => setScreen("lobby")}
      />
    );
  }

  return (
    <LandscapeFrame orientation={screen === "game" ? "portrait" : "landscape"}>
      {body}
    </LandscapeFrame>
  );
}
