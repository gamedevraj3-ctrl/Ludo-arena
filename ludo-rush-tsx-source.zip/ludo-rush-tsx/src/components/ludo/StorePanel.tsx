import { Box, ChevronUp, Package, Shirt, Sparkles, Star, Sword, User } from "lucide-react";
import { useState } from "react";
import { Sfx } from "@/game/audio";

const TABS = [
  { id: "featured", label: "FEATURED", icon: Star },
  { id: "characters", label: "CHARACTERS", icon: User },
  { id: "skins", label: "SKINS", icon: Shirt },
  { id: "weapons", label: "WEAPONS", icon: Sword },
  { id: "bundles", label: "BUNDLES", icon: Package },
  { id: "other", label: "OTHER", icon: Box },
] as const;

export function StorePanel({ onClose }: { onClose: () => void }) {
  const [tab, setTab] = useState<(typeof TABS)[number]["id"]>("featured");
  const active = TABS.find((t) => t.id === tab)!;

  return (
    <div className="ff-sheet">
      <header className="ff-sheet-head">
        <button type="button" className="ff-icon-btn" onClick={onClose} aria-label="Close">
          <ChevronUp className="h-5 w-5" />
        </button>
        <h1 className="ff-sheet-title">STORE</h1>
        <div className="ff-wallet">
          <span className="ff-coin">1,250</span>
          <span className="ff-gem">320</span>
        </div>
      </header>

      <div className="ff-sheet-body">
        <nav className="ff-side-tabs" aria-label="Store sections">
          {TABS.map((t) => {
            const Icon = t.icon;
            const on = tab === t.id;
            return (
              <button
                key={t.id}
                type="button"
                className={`ff-side-tab ${on ? "is-on" : ""}`}
                onClick={() => {
                  Sfx.tap();
                  setTab(t.id);
                }}
              >
                <Icon className="h-4 w-4" />
                <span>{t.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="ff-store-empty">
          <Sparkles className="h-10 w-10 text-gold" />
          <h2>No items in {active.label}</h2>
          <p>The store is empty for now. Check back after the next drop.</p>
        </div>
      </div>
    </div>
  );
}
