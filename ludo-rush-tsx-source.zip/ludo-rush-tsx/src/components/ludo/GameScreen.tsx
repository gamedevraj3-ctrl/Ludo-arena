import { useEffect, useRef, useState } from "react";
import { BookOpen, Flag, Heart, Play, Settings, Timer, Volume2, VolumeX, X } from "lucide-react";
import { BoardCanvas } from "./BoardCanvas";
import { LudoEngine, baseRect, tokenCell } from "@/game/engine";
import { cellFor, centerOf } from "@/game/board";
import { assetFor } from "@/game/characters";
import { Sfx } from "@/game/audio";
import type { GameConfig, PColor, Player, SpeedPreset, Token } from "@/game/types";
import { COLOR_DARK, COLOR_MAIN, livesLeft, tokensHome } from "@/game/types";

const ALL_COLORS: PColor[] = ["yellow", "blue", "green", "red"];
const SPEED_OPTIONS: { id: SpeedPreset; label: string; hint: string }[] = [
  { id: "relaxed", label: "Relaxed", hint: "Slow and easy to follow" },
  { id: "normal", label: "Normal", hint: "Human-like pace" },
  { id: "fast", label: "Fast", hint: "Quick moves for pros" },
];

function DiceFace({ value, size }: { value: number | null; size: number }) {
  const dots: Record<number, [number, number][]> = {
    1: [[0.5, 0.5]],
    2: [[0.28, 0.28], [0.72, 0.72]],
    3: [[0.26, 0.26], [0.5, 0.5], [0.74, 0.74]],
    4: [[0.28, 0.28], [0.72, 0.28], [0.28, 0.72], [0.72, 0.72]],
    5: [[0.26, 0.26], [0.74, 0.26], [0.5, 0.5], [0.26, 0.74], [0.74, 0.74]],
    6: [[0.28, 0.24], [0.72, 0.24], [0.28, 0.5], [0.72, 0.5], [0.28, 0.76], [0.72, 0.76]],
  };
  return (
    <div
      className="relative rounded-[22%] bg-linear-to-br from-white to-[#cfc9e0] shadow-md"
      style={{ width: size, height: size }}
    >
      {(value ? dots[value] : []).map(([x, y], i) => (
        <span
          key={i}
          className="absolute rounded-full bg-primary"
          style={{
            width: size * 0.16,
            height: size * 0.16,
            left: x * size - size * 0.08,
            top: y * size - size * 0.08,
          }}
        />
      ))}
    </div>
  );
}

function PawnMark({ color, size, highlight, count }: { color: PColor; size: number; highlight: boolean; count: number }) {
  return (
    <div className="relative" style={{ width: size, height: size * 1.15 }}>
      <svg viewBox="0 0 40 46" width={size} height={size * 1.15}>
        <ellipse cx="20" cy="41" rx="12" ry="3.5" fill="rgba(0,0,0,0.28)" />
        <defs>
          <linearGradient id={`p-${color}`} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#fff" stopOpacity="0.35" />
            <stop offset="40%" stopColor={COLOR_MAIN[color]} />
            <stop offset="100%" stopColor={COLOR_DARK[color]} />
          </linearGradient>
        </defs>
        {highlight && <circle cx="20" cy="33" r="14" fill="rgba(255,255,255,0.28)" />}
        <ellipse cx="20" cy="36" rx="13" ry="6" fill={`url(#p-${color})`} stroke="#fff" strokeWidth="1.2" />
        <path d="M10 36 Q14 22 12 18 H28 Q26 22 30 36 Z" fill={`url(#p-${color})`} stroke="#fff" strokeWidth="1.1" />
        <circle cx="20" cy="14" r="8.5" fill={`url(#p-${color})`} stroke="#fff" strokeWidth="1.3" />
        <circle cx="17" cy="11" r="2.4" fill="rgba(255,255,255,0.55)" />
      </svg>
      {count > 1 && (
        <span className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full border border-white bg-green text-[9px] font-black">
          {count}
        </span>
      )}
    </div>
  );
}

function rulesText(config: GameConfig) {
  if (config.matchMode === "classic") {
    return [
      "Roll a 6 to bring a token out of your base yard.",
      "Rolling a 6 grants you an extra turn.",
      "Three 6s in a row: the roll is void and your turn is lost.",
      "Land exactly on a rival token to send it back to its yard — that also earns an extra turn.",
      "Star cells and coloured start boxes are safe; nobody can be cut there.",
      "A block of 2+ tokens of the same colour cannot be cut anywhere.",
      "You need the exact count to enter HOME.",
      "Miss 3 turns in a row and you are eliminated.",
      "First player to bring all 4 tokens HOME wins.",
    ];
  }
  return [
    `The match lasts ${Math.floor(config.matchSeconds / 60)} minutes — highest score when the clock hits zero wins.`,
    "All 4 tokens start OPEN, so no 6 is needed to move out.",
    "Every step forward scores 1 point.",
    "Bringing a token HOME adds a +56 bonus.",
    "Cut a rival token and ALL of its points transfer to you.",
    "Star cells and coloured start boxes are safe zones.",
    "A block of 2+ tokens of the same colour cannot be cut anywhere.",
    "Rolling a 6 or cutting a token grants an extra turn.",
    "Three 6s in a row: the roll is void and your turn is lost.",
    "Let the turn timer run out and the turn is missed. Three misses eliminate you.",
  ];
}

export function GameView({
  config,
  onFinish,
  onLeave,
}: {
  config: GameConfig;
  onFinish: (engine: LudoEngine) => void;
  onLeave: () => void;
}) {
  const engineRef = useRef<LudoEngine | null>(null);
  const [, bump] = useState(0);
  const [boardSize, setBoardSize] = useState(340);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [rulesOpen, setRulesOpen] = useState(false);
  const [soundOn, setSoundOn] = useState(() => Sfx.enabled);
  const wrapRef = useRef<HTMLDivElement>(null);
  const pnp = config.mode === "passAndPlay";

  useEffect(() => {
    const engine = new LudoEngine(config, (s) => Sfx.play(s));
    engineRef.current = engine;
    const unsub = engine.subscribe(() => {
      bump((n) => n + 1);
      if (engine.finished) {
        window.setTimeout(() => onFinish(engine), 1200);
      }
    });
    engine.start();
    return () => {
      unsub();
      engine.dispose();
    };
  }, [config, onFinish]);

  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const ro = new ResizeObserver(() => {
      const w = el.clientWidth;
      const h = el.clientHeight;
      const outer = pnp ? 0.445 : 0;
      setBoardSize(Math.max(220, Math.min(w - 12, (h * 0.92) / (1 + outer))));
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, [pnp]);

  const engine = engineRef.current;
  if (!engine) return <div className="ludo-shell h-dvh" />;
  const game = engine;
  const snap = game.snapshot();
  const u = boardSize / 15;
  const plateW = u * 4.9;
  const plateH = plateW * 0.62;
  const gap = u * 0.3;
  const pad = pnp ? plateH + gap : 0;
  const turnFrac = snap.finished ? 0 : snap.turnRemaining / Math.max(1, config.turnSeconds);

  function openSettings() {
    game.pause();
    setSettingsOpen(true);
    setRulesOpen(false);
  }
  function closeSettings() {
    setSettingsOpen(false);
    setRulesOpen(false);
    game.resume();
  }

  return (
    <div className="ludo-shell ff-board relative flex h-full flex-col text-fg">
      <header className="relative flex items-start justify-between px-4 pt-2">
        <button
          type="button"
          onClick={openSettings}
          className="flex h-12 w-12 flex-col items-center justify-center rounded-full bg-primary text-white shadow-lg"
          aria-label="Settings"
        >
          <Settings className="h-6 w-6" />
        </button>
        <div className="absolute left-1/2 top-2 -translate-x-1/2 flex items-center gap-2 rounded-full bg-primary px-5 py-2 text-xl font-black tracking-wide text-white shadow-lg">
          {config.matchMode === "rush" ? <Timer className="h-5 w-5" /> : null}
          {config.matchMode === "rush" ? (snap.remainingMatch > 0 ? game.clockText : "00:00") : "CLASSIC"}
        </div>
        <div className="h-12 w-12" />
      </header>

      <div ref={wrapRef} className="flex min-h-0 flex-1 items-center justify-center px-2">
        <div className="relative" style={{ width: boardSize, height: boardSize + pad * 2 }}>
          {pnp &&
            snap.players.map((p) => {
              const live =
                !snap.finished &&
                !snap.paused &&
                game.current.id === p.id &&
                snap.dice == null &&
                !snap.rolling &&
                !snap.moving;
              const isTurn = game.current.id === p.id && !snap.finished;
              const face = isTurn ? (snap.dice ?? p.lastDice) : p.lastDice;
              const onLeft = p.seat === "topLeft" || p.seat === "bottomLeft";
              const onTop = p.seat === "topLeft" || p.seat === "topRight";
              return (
                <CornerDice
                  key={p.id}
                  color={p.color}
                  value={face}
                  live={live}
                  rolling={snap.rolling && isTurn}
                  turnProgress={isTurn ? turnFrac : null}
                  width={plateW}
                  pinOnLeft={!onLeft}
                  style={{
                    left: onLeft ? 0 : boardSize - plateW,
                    top: onTop ? pad - plateH - gap : pad + boardSize + gap,
                  }}
                  onRoll={() => {
                    if (!live) return;
                    Sfx.tap();
                    void game.rollDice();
                  }}
                />
              );
            })}

          <div className="absolute" style={{ left: 0, top: pad, width: boardSize, height: boardSize }}>
            <BoardCanvas size={boardSize} />
            {ALL_COLORS.filter((c) => !snap.players.some((p) => p.color === c)).map((c) => {
              const rect = baseRect(c, boardSize);
              return (
                <div
                  key={c}
                  className="absolute rounded-[14px] opacity-30"
                  style={{
                    left: rect.left,
                    top: rect.top,
                    width: rect.width,
                    height: rect.height,
                    background: `linear-gradient(135deg, ${COLOR_MAIN[c]}, ${COLOR_DARK[c]})`,
                  }}
                />
              );
            })}
            {snap.players.map((p) => (
              <SeatPanel
                key={p.id}
                player={p}
                size={boardSize}
                isTurn={snap.currentIndex === p.id && !snap.finished}
                showScore={config.matchMode === "rush"}
                showDice={!pnp}
                dice={game.current.id === p.id ? snap.dice : p.lastDice}
              />
            ))}
            <MoveHints engine={game} size={boardSize} u={u} />
            <Tokens engine={game} size={boardSize} u={u} />
            {snap.toast && (
              <div className="absolute bottom-[-6%] left-1/2 z-20 w-[102%] -translate-x-1/2 rounded-xl border border-accent/60 bg-[#241546]/95 px-3 py-2 text-center text-[12.5px] font-extrabold">
                {snap.toast}
              </div>
            )}
          </div>
        </div>
      </div>

      <footer className="px-4 pb-3 pt-1 text-center">
        <p className={`text-[12.5px] font-extrabold ${game.myTurn || pnp ? "text-gold" : "text-muted"}`}>
          {snap.finished
            ? ""
            : pnp
              ? snap.dice == null
                ? `${game.current.name} — tap your dice`
                : `${game.current.name} — pick a token`
              : game.myTurn
                ? snap.dice == null
                  ? "Your turn — tap the dice"
                  : "Select a token to move"
                : `${game.current.name} is playing…`}
        </p>
        {!pnp && (
          <button
            type="button"
            disabled={!(game.myTurn && snap.dice == null && !snap.rolling)}
            onClick={() => {
              Sfx.tap();
              void game.rollDice();
            }}
            className={`relative mx-auto mt-2 flex h-16 w-16 items-center justify-center rounded-2xl border-2 border-white/40 bg-linear-to-br from-white to-[#d9d4ec] shadow-xl disabled:opacity-50 ${
              game.myTurn && snap.dice == null ? "dice-live" : ""
            }`}
            aria-label="Roll dice"
          >
            <svg className="absolute inset-0 h-full w-full -rotate-90" viewBox="0 0 64 64">
              <circle cx="32" cy="32" r="28" fill="none" stroke="rgba(91,61,209,0.18)" strokeWidth="4" />
              <circle
                cx="32"
                cy="32"
                r="28"
                fill="none"
                stroke={COLOR_MAIN[game.current.color]}
                strokeWidth="4"
                strokeDasharray={`${turnFrac * 176} 176`}
                strokeLinecap="round"
              />
            </svg>
            <DiceFace value={snap.dice} size={48} />
          </button>
        )}
        {pnp && (
          <p className="mt-2 text-[11px] font-bold text-muted">Pass the phone — roll from your corner.</p>
        )}
      </footer>

      {settingsOpen && (
        <div className="absolute inset-0 z-40 flex items-end justify-center bg-black/55 p-3 sm:items-center">
          <div className="w-full max-w-md rounded-2xl border border-stroke bg-surface p-4 shadow-2xl">
            <div className="mb-3 flex items-center justify-between">
              <div>
                <h2 className="text-lg font-black">Settings</h2>
                <p className="text-[11px] font-bold text-muted">Game paused</p>
              </div>
              <button type="button" onClick={closeSettings} className="rounded-full p-2" aria-label="Close">
                <X className="h-5 w-5" />
              </button>
            </div>

            {rulesOpen ? (
              <div className="max-h-[50vh] overflow-y-auto pr-1">
                <h3 className="mb-2 text-sm font-black text-gold">
                  {config.matchMode === "rush" ? "Rush Ludo" : "Classic Ludo"} Rules
                </h3>
                <ul className="space-y-2 text-sm font-semibold text-muted">
                  {rulesText(config).map((line) => (
                    <li key={line}>• {line}</li>
                  ))}
                </ul>
                <button
                  type="button"
                  onClick={() => setRulesOpen(false)}
                  className="mt-3 w-full rounded-xl border border-stroke py-2 text-sm font-black"
                >
                  Back
                </button>
              </div>
            ) : (
              <>
                <p className="mb-2 text-[11px] font-bold tracking-wide text-muted">GAME SPEED</p>
                <div className="mb-3 grid grid-cols-3 gap-2">
                  {SPEED_OPTIONS.map((sp) => {
                    const sel = game.config.speed === sp.id;
                    return (
                      <button
                        key={sp.id}
                        type="button"
                        onClick={() => game.setSpeed(sp.id)}
                        className={`rounded-xl py-2 text-xs font-black ${
                          sel ? "bg-primary text-fg" : "bg-black/30 text-muted"
                        }`}
                      >
                        {sp.label}
                      </button>
                    );
                  })}
                </div>
                <button
                  type="button"
                  onClick={() => {
                    const next = !soundOn;
                    Sfx.setEnabled(next);
                    setSoundOn(next);
                    if (next) Sfx.tap();
                  }}
                  className="mb-2 flex w-full items-center gap-3 rounded-xl bg-black/25 px-3 py-2.5 text-sm font-extrabold"
                >
                  {soundOn ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
                  {soundOn ? "Sound on" : "Muted"}
                </button>
                <button
                  type="button"
                  onClick={() => setRulesOpen(true)}
                  className="mb-2 flex w-full items-center gap-3 rounded-xl bg-black/25 px-3 py-2.5 text-sm font-extrabold"
                >
                  <BookOpen className="h-4 w-4" />
                  {config.matchMode === "rush" ? "Rush" : "Classic"} rules
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setSettingsOpen(false);
                    game.resume();
                    game.forceFinish();
                  }}
                  className="mb-2 flex w-full items-center gap-3 rounded-xl bg-black/25 px-3 py-2.5 text-sm font-extrabold text-red"
                >
                  <Flag className="h-4 w-4" />
                  Resign match
                </button>
                <button
                  type="button"
                  onClick={closeSettings}
                  className="flex w-full items-center justify-center gap-2 rounded-xl bg-green py-2.5 text-sm font-black"
                >
                  <Play className="h-4 w-4" />
                  Resume
                </button>
                <button
                  type="button"
                  onClick={() => {
                    game.forceFinish();
                    onLeave();
                  }}
                  className="mt-2 w-full py-2 text-xs font-bold text-muted"
                >
                  Leave to lobby
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function CornerDice({
  color,
  value,
  live,
  rolling,
  turnProgress,
  width,
  pinOnLeft,
  style,
  onRoll,
}: {
  color: PColor;
  value: number | null;
  live: boolean;
  rolling: boolean;
  turnProgress: number | null;
  width: number;
  pinOnLeft: boolean;
  style: { left: number; top: number };
  onRoll: () => void;
}) {
  const h = width * 0.62;
  const pin = (
    <div
      className="relative flex h-full items-center justify-center"
      style={{
        width: "40%",
        background: `linear-gradient(180deg, ${COLOR_MAIN[color]}, ${COLOR_DARK[color]})`,
      }}
    >
      {turnProgress != null && (
        <svg className="absolute inset-1 -rotate-90" viewBox="0 0 36 36">
          <circle cx="18" cy="18" r="14" fill="none" stroke="rgba(255,255,255,0.25)" strokeWidth="3" />
          <circle
            cx="18"
            cy="18"
            r="14"
            fill="none"
            stroke="#fff"
            strokeWidth="3"
            strokeDasharray={`${turnProgress * 88} 88`}
            strokeLinecap="round"
          />
        </svg>
      )}
      <div className="h-2.5 w-2.5 rounded-full bg-white/90" />
    </div>
  );
  const tray = (
    <div className="flex h-full flex-1 items-center justify-center bg-[#1a1238]">
      <DiceFace value={rolling ? value : value} size={h * 0.62} />
    </div>
  );
  return (
    <button
      type="button"
      disabled={!live}
      onClick={onRoll}
      className={`absolute z-20 overflow-hidden border-[3px] p-0 ${live ? "dice-live border-gold" : "border-gold/60"}`}
      style={{
        left: style.left,
        top: style.top,
        width,
        height: h,
        borderRadius: h * 0.26,
        boxShadow: live ? `0 0 16px ${COLOR_MAIN[color]}` : "0 6px 14px rgb(0 0 0 / 0.4)",
      }}
      aria-label="Roll dice"
    >
      <div className="flex h-full w-full">
        {pinOnLeft ? (
          <>
            {pin}
            {tray}
          </>
        ) : (
          <>
            {tray}
            {pin}
          </>
        )}
      </div>
    </button>
  );
}

function SeatPanel({
  player,
  size,
  isTurn,
  showScore,
  showDice,
  dice,
}: {
  player: Player;
  size: number;
  isTurn: boolean;
  showScore: boolean;
  showDice: boolean;
  dice: number | null;
}) {
  const rect = baseRect(player.color, size);
  return (
    <div
      className="absolute overflow-hidden"
      style={{
        left: rect.left,
        top: rect.top,
        width: rect.width,
        height: rect.height,
        borderRadius: Math.max(10, rect.width * 0.08),
        background: `linear-gradient(160deg, ${COLOR_MAIN[player.color]}, ${COLOR_DARK[player.color]})`,
        boxShadow: isTurn ? "0 0 16px 2px rgb(255 255 255 / 0.35)" : undefined,
        outline: isTurn ? "2.4px solid white" : "1px solid rgb(255 255 255 / 0.18)",
        opacity: player.eliminated ? 0.45 : 1,
      }}
    >
      <img
        src={assetFor(player.character)}
        alt=""
        className="absolute inset-0 h-full w-full object-cover object-top"
        draggable={false}
      />
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background: "linear-gradient(180deg, transparent 42%, rgb(0 0 0 / 0.55) 100%)",
        }}
      />
      <div className="absolute right-2 top-2 flex flex-col items-end text-white">
        {showDice && dice != null && (
          <div className="mb-1">
            <DiceFace value={dice} size={Math.max(18, rect.width * 0.18)} />
          </div>
        )}
        <div className="text-[10px] font-bold tracking-wide text-white/90">{showScore ? "Score" : "Home"}</div>
        <div className="text-2xl font-black leading-none drop-shadow">
          {showScore ? player.score : `${tokensHome(player)}/4`}
        </div>
      </div>
      <div className="absolute inset-x-0 bottom-0 flex items-end justify-between px-2 py-1.5">
        <div className="min-w-0">
          <div className="truncate text-sm font-black leading-tight text-white drop-shadow">
            {player.realName ?? player.name}
          </div>
          {player.realName && (
            <div className="truncate text-[11px] font-bold text-white/85">{player.character}</div>
          )}
        </div>
        <div className="flex gap-0.5 pb-0.5">
          {[0, 1, 2].map((i) => (
            <Heart
              key={i}
              className={`h-3.5 w-3.5 ${i < livesLeft(player) ? "fill-white text-white" : "text-white/35"}`}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

function MoveHints({ engine, size, u }: { engine: LudoEngine; size: number; u: number }) {
  const snap = engine.snapshot();
  if (!engine.myTurn || snap.dice == null || snap.movable.length === 0) return null;
  const p = engine.current;
  const d = snap.dice;
  return (
    <>
      {snap.movable.map((idx) => {
        const t = p.tokens[idx];
        const cell = t.open ? cellFor(p.color, t.pos + d) : cellFor(p.color, 0);
        const c = centerOf(cell, size);
        return (
          <div
            key={`hint-${idx}`}
            className="hint-ring pointer-events-none absolute z-10 rounded-full border-2"
            style={{
              left: c.x - u * 0.44,
              top: c.y - u * 0.44,
              width: u * 0.88,
              height: u * 0.88,
              borderColor: COLOR_MAIN[p.color],
              background: `${COLOR_MAIN[p.color]}33`,
            }}
          />
        );
      })}
    </>
  );
}

function Tokens({
  engine,
  size,
  u,
}: {
  engine: LudoEngine;
  size: number;
  u: number;
}) {
  const snap = engine.snapshot();
  type Ref = { player: Player; token: Token; cellKey: string; cell: { r: number; c: number } };
  const byCell = new Map<string, Ref[]>();
  for (const p of snap.players) {
    for (const t of p.tokens) {
      const cell = tokenCell(p, t);
      const key = `${cell.r}_${cell.c}`;
      const list = byCell.get(key) ?? [];
      list.push({ player: p, token: t, cellKey: key, cell });
      byCell.set(key, list);
    }
  }

  const widgets: React.ReactNode[] = [];
  byCell.forEach((list, key) => {
    const byOwner = new Map<number, Ref[]>();
    for (const ref of list) {
      const arr = byOwner.get(ref.player.id) ?? [];
      arr.push(ref);
      byOwner.set(ref.player.id, arr);
    }
    const groups = [...byOwner.values()];
    groups.forEach((stack, g) => {
      const p = stack[0].player;
      const base = centerOf(stack[0].cell, size);
      let dx = 0;
      let dy = 0;
      if (groups.length > 1) {
        const a = ((2 * Math.PI) / groups.length) * g - Math.PI / 2;
        const r = u * (groups.length === 2 ? 0.18 : 0.24);
        dx = Math.cos(a) * r;
        dy = Math.sin(a) * r;
      }
      const pickable = stack.find((r) => snap.movable.includes(r.token.index)) ?? stack[0];
      const canMove =
        engine.myTurn &&
        snap.dice != null &&
        engine.current.id === p.id &&
        snap.movable.includes(pickable.token.index);
      const isCurrent = !snap.finished && engine.current.id === p.id;
      const hopping = isCurrent && snap.hopToken != null && stack.some((r) => r.token.index === snap.hopToken);
      const pawnW = u * (stack[0].token.finished ? 0.6 : 0.8) * (isCurrent ? 1.22 : 1);
      widgets.push(
        <button
          key={`stk_${p.id}_${key}_${g}`}
          type="button"
          disabled={!canMove}
          onClick={() => {
            if (canMove) {
              Sfx.tap();
              void engine.moveToken(pickable.token.index);
            }
          }}
          className={`absolute z-10 origin-bottom border-0 bg-transparent p-0 ${hopping ? "token-hop" : ""}`}
          style={{
            left: base.x + dx - pawnW / 2,
            top: base.y + dy - pawnW * 0.78,
            width: pawnW,
            zIndex: isCurrent ? 12 : 10,
          }}
        >
          <PawnMark color={p.color} size={pawnW} highlight={canMove} count={stack.length} />
        </button>,
      );
    });
  });

  return <>{widgets}</>;
}