import type { ReactNode } from "react";

export function LandscapeFrame({
  children,
  orientation = "landscape",
}: {
  children: ReactNode;
  orientation?: "landscape" | "portrait";
}) {
  return (
    <div className={`ls-root ls-${orientation}`}>
      <div className="ls-stage">{children}</div>
    </div>
  );
}
