import { useMemo, useState } from "react";
import { ChevronUp, Shield, Sparkles, Star, Swords, Users } from "lucide-react";
import { ROLES, ROSTER, assetFor, type CharRole } from "@/game/characters";
import { Sfx } from "@/game/audio";

const TABS: { id: "all" | CharRole; label: string; icon: typeof Star }[] = [
  { id: "all", label: "ALL", icon: Star },
  { id: "assault", label: "ASSAULT", icon: Swords },
  { id: "defense", label: "DEFENSE", icon: Shield },
  { id: "support", label: "SUPPORT", icon: Users },
  { id: "special", label: "SPECIAL", icon: Sparkles },
];

export function CharacterBook({
  selected,
  onSelect,
  onClose,
}: {
  selected: string;
  onSelect: (name: string) => void;
  onClose: () => void;
}) {
  const [tab, setTab] = useState<(typeof TABS)[number]["id"]>("all");
  const list = useMemo(
    () => (tab === "all" ? [...ROSTER] : ROSTER.filter((n) => ROLES[n] === tab)),
    [tab],
  );

  return (
    <div className="ff-sheet">
      <header className="ff-sheet-head">
        <button type="button" className="ff-icon-btn" onClick={onClose} aria-label="Close">
          <ChevronUp className="h-5 w-5" />
        </button>
        <h1 className="ff-sheet-title">CHARACTER</h1>
        <div className="ff-chip">Default</div>
      </header>

      <div className="ff-sheet-body">
        <nav className="ff-side-tabs" aria-label="Character class">
          {TABS.map((t) => {
            const Icon = t.icon;
            const on = tab === t.id;
            return (
              <button
                key={t.id}
                type="button"
                className={`ff-side-tab ${on ? "is-on" : ""}`}
                onClick={() => {
                  Sfx.tap();
                  setTab(t.id);
                }}
              >
                <Icon className="h-4 w-4" />
                <span>{t.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="ff-char-grid">
          {list.map((name) => {
            const on = name === selected;
            return (
              <article key={name} className={`ff-char-card ${on ? "is-on" : ""}`}>
                <div className="ff-char-art">
                  <img src={assetFor(name)} alt="" />
                </div>
                <div className="ff-char-meta">
                  <p className="ff-char-name">{name}</p>
                  <p className="ff-char-lv">Lv. 1</p>
                </div>
                <button
                  type="button"
                  className="ff-select-btn"
                  onClick={() => {
                    Sfx.tap();
                    onSelect(name);
                  }}
                >
                  {on ? "EQUIPPED" : "SELECT"}
                </button>
              </article>
            );
          })}
        </div>
      </div>
    </div>
  );
}
