import { useEffect, useMemo, useRef } from "react";
import { assetFor } from "@/game/characters";
import type { GameConfig, ScoreRow } from "@/game/types";
import { COLOR_DARK, COLOR_MAIN } from "@/game/types";

const SLOTS = [0.42, 0.64, 0.18, 0.84];
const SCALES = [1, 0.84, 0.78, 0.7];
const LIFTS = [0, 0.08, 0.1, 0.14];
const RANKS = ["1st", "2nd", "3rd", "4th"];

export function BooyahScreen({
  rows,
  config,
  onLobby,
  onAgain,
}: {
  rows: ScoreRow[];
  config: GameConfig;
  onLobby: () => void;
  onAgain: () => void;
}) {
  const winner = rows[0];
  const iWon = winner?.isMe ?? false;
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const c = canvasRef.current;
    if (!c) return;
    const ctx = c.getContext("2d");
    if (!ctx) return;
    let raf = 0;
    const start = performance.now();
    const flecks = Array.from({ length: 70 }, (_, i) => ({
      x: Math.random(),
      phase: Math.random(),
      speed: 0.55 + Math.random() * 0.85,
      sway: 0.012 + Math.random() * 0.045,
      size: 4 + Math.random() * 6,
      color: ["#ffd447", "#ff5a6e", "#4ce06b", "#4fa8ff", "#b78cff", "#fff"][i % 6],
    }));
    const draw = (now: number) => {
      const t = ((now - start) / 6000) % 1;
      const w = c.width;
      const h = c.height;
      ctx.clearRect(0, 0, w, h);
      for (const f of flecks) {
        const prog = (t * f.speed + f.phase) % 1;
        const y = prog * (h + 60) - 30;
        const x = f.x * w + Math.sin((prog * 2 + f.phase) * Math.PI * 2) * w * f.sway;
        ctx.globalAlpha = prog > 0.85 ? (1 - prog) / 0.15 : 0.85;
        ctx.fillStyle = f.color;
        ctx.fillRect(x, y, f.size, f.size * 0.55);
      }
      ctx.globalAlpha = 1;
      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, []);

  const paintOrder = useMemo(() => {
    const order: number[] = [];
    if (rows.length > 3) order.push(3);
    if (rows.length > 2) order.push(2);
    if (rows.length > 1) order.push(1);
    order.push(0);
    return order;
  }, [rows.length]);

  const classic = config.matchMode === "classic";

  return (
    <div className="ludo-shell relative flex h-full flex-col overflow-hidden text-fg">
      <canvas
        ref={canvasRef}
        width={1280}
        height={720}
        className="pointer-events-none absolute inset-0 h-full w-full opacity-80"
      />
      <div className="relative z-10 flex min-h-0 flex-1 flex-col px-4 py-3 sm:px-8">
        <div className="text-center">
          <h1 className="booyah-title text-[clamp(48px,12vw,92px)]">BOOYAH</h1>
          <div className="mx-auto mt-1 inline-block rounded-full bg-linear-to-r from-gold to-gold-deep px-3.5 py-1 text-[11px] font-black tracking-[0.16em] text-[#3a2200]">
            {iWon ? "YOU ARE MVP" : `${winner?.name.toUpperCase()}  ·  MVP`}
          </div>
          <p className="mt-2 text-sm font-bold text-muted">
            {classic
              ? iWon
                ? `You brought ${winner.tokensHome} of 4 tokens home first!`
                : `${winner.name} got their tokens home first`
              : iWon
                ? `Highest score — ${winner.score} points!`
                : `${winner.name} scored highest`}
          </p>
        </div>

        <div className="relative mx-auto min-h-0 w-full max-w-5xl flex-1">
          {paintOrder.map((i) => {
            const row = rows[i];
            if (!row) return null;
            const scale = SCALES[i];
            const left = `${SLOTS[i] * 100}%`;
            const top = `${LIFTS[i] * 100}%`;
            const z = 10 - i;
            return (
              <div
                key={row.character + i}
                className="absolute flex -translate-x-1/2 flex-col items-center"
                style={{
                  left,
                  top,
                  width: `${22 * scale}%`,
                  height: `${88 * scale}%`,
                  zIndex: z,
                }}
              >
                {i === 0 ? (
                  <span className="mb-1 rounded-full bg-gold px-2 py-0.5 text-[10px] font-black tracking-widest text-[#3a2200]">
                    MVP
                  </span>
                ) : (
                  <span className="mb-1 rounded-full bg-black/45 px-2 py-0.5 text-[10px] font-black tracking-widest text-muted">
                    {RANKS[i]}
                  </span>
                )}
                <div className="relative min-h-0 w-full flex-1">
                  <div
                    className="absolute inset-x-[4%] bottom-0 h-[22%] rounded-full blur-md"
                    style={{
                      background: `radial-gradient(circle, ${COLOR_MAIN[row.color]} 0%, ${COLOR_DARK[row.color]} 38%, transparent 72%)`,
                    }}
                  />
                  <div
                    className="absolute inset-x-[18%] bottom-[2%] h-[8%] rounded-full"
                    style={{ background: COLOR_MAIN[row.color], opacity: 0.85 }}
                  />
                  <img
                    src={assetFor(row.character)}
                    alt={row.name}
                    className="relative h-full w-full object-contain object-bottom"
                    draggable={false}
                  />
                </div>
                <div className="mt-1 text-center">
                  <div className={`font-black ${i === 0 ? "text-sm" : "text-xs"} text-fg`}>
                    {row.name}
                  </div>
                  <div className={`text-[11px] font-extrabold ${i === 0 ? "text-gold" : "text-muted"}`}>
                    {classic ? `Home ${row.tokensHome}/4` : `${row.score} pts`}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <div className="mx-auto mt-2 flex w-full max-w-md gap-3 pb-2">
          <button
            type="button"
            onClick={onLobby}
            className="flex-1 rounded-[13px] border-2 border-stroke py-2.5 text-sm font-black tracking-wide"
          >
            LOBBY
          </button>
          <button
            type="button"
            onClick={onAgain}
            className="flex-1 rounded-[13px] bg-primary py-2.5 text-sm font-black tracking-wide shadow-[0_8px_20px_rgb(91_61_209_/_0.45)]"
          >
            PLAY AGAIN
          </button>
        </div>
      </div>
    </div>
  );
}

export function demoRows(): ScoreRow[] {
  return [
    { name: "You", color: "green", score: 214, tokensHome: 2, isMe: true, eliminated: false, progress: 120, character: "A124" },
    { name: "Kassie", color: "blue", score: 168, tokensHome: 1, isMe: false, eliminated: false, progress: 90, character: "Kassie" },
    { name: "Wolfrah", color: "yellow", score: 141, tokensHome: 1, isMe: false, eliminated: false, progress: 80, character: "Wolfrah" },
    { name: "Misha", color: "red", score: 97, tokensHome: 0, isMe: false, eliminated: false, progress: 50, character: "Misha" },
  ];
}