import type { GameSfx } from "./types";

const FILES: Record<GameSfx, string> = {
  matchStart: "/sfx/match_start.wav",
  diceRoll: "/sfx/dice_roll.wav",
  diceSix: "/sfx/dice_six.wav",
  hop: "/sfx/hop.wav",
  tokenOpen: "/sfx/token_open.wav",
  cut: "/sfx/cut.wav",
  home: "/sfx/home.wav",
  extraTurn: "/sfx/extra_turn.wav",
  noMove: "/sfx/no_move.wav",
  miss: "/sfx/miss.wav",
  forfeit: "/sfx/forfeit.wav",
  win: "/sfx/win.wav",
  lose: "/sfx/lose.wav",
  tap: "/sfx/tap.wav",
};

let enabled = true;
const cache = new Map<string, HTMLAudioElement>();

function load(src: string) {
  let a = cache.get(src);
  if (!a) {
    a = new Audio(src);
    a.preload = "auto";
    cache.set(src, a);
  }
  return a;
}

export const Sfx = {
  get enabled() {
    return enabled;
  },
  setEnabled(v: boolean) {
    enabled = v;
    try {
      localStorage.setItem("ludo_sound", v ? "1" : "0");
    } catch {
      /* ignore */
    }
  },
  init() {
    try {
      enabled = localStorage.getItem("ludo_sound") !== "0";
    } catch {
      enabled = true;
    }
    Object.values(FILES).forEach((src) => load(src));
  },
  play(s: GameSfx) {
    if (!enabled) return;
    const a = load(FILES[s]).cloneNode(true) as HTMLAudioElement;
    a.volume = s === "hop" ? 0.45 : 0.7;
    void a.play().catch(() => {});
  },
  tap() {
    this.play("tap");
  },
};
