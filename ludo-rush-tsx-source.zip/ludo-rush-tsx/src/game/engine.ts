import {
  BASE_ORIGIN,
  HOME_STEP,
  LAST_RING_STEP,
  cellFor,
  isSafePos,
  ringIndexFor,
  yardSlot,
} from "./board";
import { pickBots } from "./characters";
import type {
  GameConfig,
  GameSfx,
  PColor,
  Player,
  ScoreRow,
  Seat,
  Token,
} from "./types";
import { allHome, isActive, tokensHome } from "./types";
import { SEAT_COLOR } from "./types";

const SPEED_FACTOR = { relaxed: 1.45, normal: 1, fast: 0.68 } as const;

function ms(base: number, factor: number) {
  return base * factor;
}

function sleep(msVal: number, isPaused: () => boolean, isDead: () => boolean) {
  return new Promise<void>((resolve) => {
    const start = performance.now();
    const tick = () => {
      if (isDead()) {
        resolve();
        return;
      }
      if (isPaused()) {
        requestAnimationFrame(tick);
        return;
      }
      if (performance.now() - start >= msVal) {
        resolve();
        return;
      }
      requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  });
}

export interface EngineSnapshot {
  players: Player[];
  currentIndex: number;
  dice: number | null;
  rolling: boolean;
  moving: boolean;
  finished: boolean;
  started: boolean;
  paused: boolean;
  remainingMatch: number;
  turnRemaining: number;
  movable: number[];
  hopToken: number | null;
  hopSeq: number;
  toast: string | null;
}

export class LudoEngine {
  config: GameConfig;
  players: Player[] = [];
  currentIndex = 0;
  dice: number | null = null;
  rolling = false;
  moving = false;
  finished = false;
  started = false;
  paused = false;
  remainingMatch = 0;
  turnRemaining = 0;
  movable: number[] = [];
  hopToken: number | null = null;
  hopSeq = 0;
  animatingToken: number | null = null;
  toast: string | null = null;
  sixStreak = 0;
  private turnEpoch = 0;
  private dead = false;
  private ticker: ReturnType<typeof setInterval> | null = null;
  private listeners = new Set<() => void>();
  private onSound?: (s: GameSfx) => void;

  constructor(config: GameConfig, onSound?: (s: GameSfx) => void) {
    this.config = config;
    this.onSound = onSound;
    this.setupPlayers();
    this.remainingMatch = config.matchSeconds;
    this.turnRemaining = config.turnSeconds;
  }

  subscribe(fn: () => void) {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  snapshot(): EngineSnapshot {
    return {
      players: this.players,
      currentIndex: this.currentIndex,
      dice: this.dice,
      rolling: this.rolling,
      moving: this.moving,
      finished: this.finished,
      started: this.started,
      paused: this.paused,
      remainingMatch: this.remainingMatch,
      turnRemaining: this.turnRemaining,
      movable: this.movable,
      hopToken: this.hopToken,
      hopSeq: this.hopSeq,
      toast: this.toast,
    };
  }

  get current() {
    return this.players[this.currentIndex];
  }
  get me() {
    return this.players.find((p) => !p.isBot) ?? this.players[0];
  }
  get myTurn() {
    return !this.current.isBot && !this.finished;
  }
  get isClassic() {
    return this.config.matchMode === "classic";
  }
  get isRush() {
    return this.config.matchMode === "rush";
  }
  get factor() {
    return SPEED_FACTOR[this.config.speed];
  }
  get clockText() {
    const m = Math.floor(this.remainingMatch / 60)
      .toString()
      .padStart(2, "0");
    const s = (this.remainingMatch % 60).toString().padStart(2, "0");
    return `${m}:${s}`;
  }

  private notify() {
    for (const l of this.listeners) l();
  }
  private sfx(s: GameSfx) {
    this.onSound?.(s);
  }
  private log(text: string) {
    this.toast = text;
    this.notify();
    window.setTimeout(() => {
      if (this.toast === text) {
        this.toast = null;
        this.notify();
      }
    }, ms(1900, this.factor));
  }
  private async wait(baseMs: number) {
    await sleep(ms(baseMs, this.factor), () => this.paused, () => this.dead || this.finished);
  }
  private sameTurn(epoch: number) {
    return !this.finished && this.turnEpoch === epoch && !this.dead;
  }

  private setupPlayers() {
    const seats2: Seat[] = ["bottomLeft", "topRight"];
    const seats3: Seat[] = ["bottomLeft", "topRight", "topLeft"];
    const seats4: Seat[] = ["bottomLeft", "topRight", "topLeft", "bottomRight"];
    const seats =
      this.config.playerCount === 2 ? seats2 : this.config.playerCount === 3 ? seats3 : seats4;
    const openAtStart = this.config.matchMode === "rush";
    const others = pickBots(seats.length - 1, this.config.myCharacter);
    this.players = seats.map((seat, i) => {
      const isHuman = this.config.mode === "passAndPlay" ? true : i === 0;
      const character = i === 0 ? this.config.myCharacter : others[i - 1];
      const tokens: Token[] = [0, 1, 2, 3].map((index) => ({
        index,
        pos: 0,
        finished: false,
        open: openAtStart,
      }));
      return {
        id: i,
        name: i === 0 ? this.config.myName : character,
        color: SEAT_COLOR[seat],
        seat,
        isBot: !isHuman,
        character,
        realName: i === 0 ? this.config.myName : null,
        score: 0,
        misses: 0,
        eliminated: false,
        tokens,
        lastDice: null,
      };
    });
  }

  start() {
    if (this.started) return;
    this.started = true;
    this.turnRemaining = this.config.turnSeconds;
    this.ticker = setInterval(() => this.tick(), 1000);
    this.sfx("matchStart");
    this.log(
      this.config.matchMode === "rush"
        ? `Match started! ${this.clockText} on the clock`
        : "Classic match — first to bring all 4 tokens home wins",
    );
    this.notify();
    void this.wait(520).then(() => this.maybeBotTurn());
  }

  dispose() {
    this.dead = true;
    if (this.ticker) clearInterval(this.ticker);
    this.listeners.clear();
  }

  pause() {
    this.paused = true;
    this.notify();
  }
  resume() {
    this.paused = false;
    this.notify();
    this.kickTurn();
  }

  setSpeed(preset: GameConfig["speed"]) {
    if (this.config.speed === preset) return;
    this.config = { ...this.config, speed: preset };
    this.notify();
  }

  forceFinish() {
    this.finish("Left the match");
  }

  private tick() {
    if (this.finished || this.paused) return;
    if (this.config.matchMode === "rush") {
      this.remainingMatch--;
      if (this.remainingMatch <= 0) {
        this.remainingMatch = 0;
        this.finish("Time up!");
        return;
      }
    }
    const busy = this.rolling || this.moving || this.current.isBot;
    if (!busy) {
      this.turnRemaining--;
      if (this.turnRemaining <= 0) this.missTurn();
    }
    this.notify();
  }

  private kickTurn() {
    if (this.finished || !this.started || this.paused) return;
    if (this.rolling || this.moving) return;
    if (this.current.isBot && this.dice == null) this.maybeBotTurn();
    else this.notify();
  }

  async rollDice() {
    if (this.finished || this.rolling || this.moving || this.paused) return;
    if (this.dice != null) return;
    const epoch = this.turnEpoch;
    this.rolling = true;
    this.notify();
    const frames = 10;
    for (let i = 0; i < frames; i++) {
      this.dice = 1 + Math.floor(Math.random() * 6);
      this.notify();
      await this.wait(60 + 105 * (i / (frames - 1)) ** 2);
      if (!this.sameTurn(epoch)) {
        this.rolling = false;
        return;
      }
    }
    this.dice = 1 + Math.floor(Math.random() * 6);
    this.current.lastDice = this.dice;
    this.rolling = false;
    this.sfx(this.dice === 6 ? "diceSix" : "diceRoll");
    this.movable = this.movableTokens(this.current, this.dice);
    this.notify();
    await this.wait(430);
    if (!this.sameTurn(epoch)) return;

    if (this.dice === 6) {
      this.sixStreak++;
      if (this.sixStreak >= 3) {
        this.log(`${this.current.name} rolled three 6s — turn forfeited!`);
        this.sfx("forfeit");
        this.movable = [];
        this.notify();
        await this.wait(1000);
        if (!this.sameTurn(epoch)) return;
        this.forfeitTurn();
        return;
      }
    } else {
      this.sixStreak = 0;
    }

    if (this.movable.length === 0) {
      this.log(`${this.current.name} rolled ${this.dice} — no move`);
      this.sfx("noMove");
      await this.wait(1000);
      if (!this.sameTurn(epoch)) return;
      this.endTurn(this.dice === 6, false);
      return;
    }

    if (this.current.isBot) {
      await this.wait(700 + (this.movable.length - 1) * 180);
      if (!this.sameTurn(epoch)) return;
      const pick = this.botChoose(this.current, this.dice, this.movable);
      await this.moveToken(pick);
    } else if (this.movable.length === 1) {
      await this.wait(560);
      if (!this.sameTurn(epoch)) return;
      await this.moveToken(this.movable[0]);
    }
  }

  async moveToken(tokenIndex: number) {
    if (this.finished || this.moving || this.dice == null) return;
    if (!this.movable.includes(tokenIndex)) return;
    this.moving = true;
    this.animatingToken = tokenIndex;
    const p = this.current;
    const t = p.tokens[tokenIndex];
    const steps = this.dice;
    this.movable = [];
    this.notify();
    await this.wait(190);

    if (!t.open) {
      t.open = true;
      t.pos = 0;
      this.hopToken = tokenIndex;
      this.hopSeq++;
      this.sfx("tokenOpen");
      this.log(`${p.name} opened a token`);
      this.notify();
      await this.wait(250);
      this.hopToken = null;
      const openCut = this.resolveCut(p, t);
      this.animatingToken = null;
      this.moving = false;
      this.notify();
      await this.wait(openCut ? 880 : 430);
      this.endTurn(true, openCut);
      return;
    }

    for (let i = 0; i < steps; i++) {
      t.pos += 1;
      if (this.isRush) p.score += 1;
      this.hopToken = tokenIndex;
      this.hopSeq++;
      this.sfx("hop");
      this.notify();
      await this.wait(i === steps - 1 ? 360 : 230);
      if (this.finished) {
        this.hopToken = null;
        this.moving = false;
        return;
      }
    }
    this.hopToken = null;

    let cut = false;
    let reachedHome = false;
    if (t.pos === HOME_STEP) {
      t.finished = true;
      if (this.isRush) p.score += 56;
      reachedHome = true;
      this.sfx("home");
      this.log(this.isRush ? `${p.name} sent a token HOME  +56` : `${p.name} sent a token HOME`);
    } else {
      cut = this.resolveCut(p, t);
    }

    this.animatingToken = null;
    this.moving = false;
    this.notify();

    if (reachedHome && allHome(p) && this.isClassic) {
      this.sfx("win");
      await this.wait(760);
      this.finish(`${p.name} brought all 4 tokens home`);
      return;
    }
    await this.wait(reachedHome ? 760 : cut ? 880 : 430);
    this.endTurn(steps === 6, cut);
  }

  private movableTokens(p: Player, d: number): number[] {
    const res: number[] = [];
    for (const t of p.tokens) {
      if (t.finished) continue;
      if (!t.open) {
        if (d === 6) res.push(t.index);
        continue;
      }
      if (t.pos + d <= HOME_STEP) res.push(t.index);
    }
    return res;
  }

  private stackSizeOn(owner: Player, ring: number) {
    let n = 0;
    for (const t of owner.tokens) {
      if (!t.open || t.finished || t.pos > LAST_RING_STEP) continue;
      if (ringIndexFor(owner.color, t.pos) === ring) n++;
    }
    return n;
  }

  private cellHasBlock(ring: number) {
    return this.players.some((o) => this.stackSizeOn(o, ring) >= 2);
  }

  private isProtected(owner: Player, pos: number) {
    if (isSafePos(owner.color, pos)) return true;
    return this.cellHasBlock(ringIndexFor(owner.color, pos));
  }

  private resolveCut(p: Player, t: Token): boolean {
    if (t.pos > LAST_RING_STEP) return false;
    if (isSafePos(p.color, t.pos)) return false;
    const myRing = ringIndexFor(p.color, t.pos);
    const onCellByOwner = new Map<number, Token[]>();
    for (const other of this.players) {
      if (other.id === p.id) continue;
      const onCell = other.tokens.filter(
        (ot) =>
          ot.open &&
          !ot.finished &&
          ot.pos <= LAST_RING_STEP &&
          ringIndexFor(other.color, ot.pos) === myRing,
      );
      if (onCell.length) onCellByOwner.set(other.id, onCell);
    }
    if (onCellByOwner.size === 0) return false;
    const hasBlock = [...onCellByOwner.values()].some((toks) => toks.length >= 2);
    if (hasBlock) return false;

    let didCut = false;
    for (const [id, toks] of onCellByOwner) {
      const other = this.players.find((pl) => pl.id === id)!;
      const ot = toks[0];
      const stolen = ot.finished ? 0 : ot.pos;
      if (this.isRush) {
        other.score = Math.max(0, other.score - stolen);
        p.score += stolen;
        this.log(`${p.name} CUT ${other.name} and stole ${stolen} points`);
      } else {
        this.log(`${p.name} cut ${other.name}'s token`);
      }
      ot.pos = 0;
      if (this.isClassic) ot.open = false;
      didCut = true;
    }
    if (didCut) this.sfx("cut");
    return didCut;
  }

  private wouldCut(p: Player, np: number) {
    if (np > LAST_RING_STEP || isSafePos(p.color, np)) return false;
    const ring = ringIndexFor(p.color, np);
    if (this.cellHasBlock(ring)) return false;
    for (const o of this.players) {
      if (o.id === p.id) continue;
      for (const ot of o.tokens) {
        if (!ot.open || ot.finished || ot.pos > LAST_RING_STEP) continue;
        if (ringIndexFor(o.color, ot.pos) !== ring) continue;
        if (this.isProtected(o, ot.pos)) continue;
        return true;
      }
    }
    return false;
  }

  private endTurn(gotSix: boolean, cut: boolean) {
    this.turnEpoch++;
    this.dice = null;
    this.movable = [];
    this.current.misses = 0;
    if (this.finished) return;
    if ((gotSix || cut) && isActive(this.current)) {
      this.turnRemaining = this.config.turnSeconds;
      this.sfx("extraTurn");
      this.log(`${this.current.name} gets an extra turn`);
      this.notify();
      void this.wait(760).then(() => this.maybeBotTurn());
      return;
    }
    this.sixStreak = 0;
    this.advanceSeat();
  }

  private forfeitTurn() {
    if (this.finished) return;
    this.turnEpoch++;
    this.dice = null;
    this.movable = [];
    this.sixStreak = 0;
    this.current.misses = 0;
    this.advanceSeat();
  }

  private missTurn() {
    if (this.finished) return;
    this.turnEpoch++;
    const p = this.current;
    p.misses++;
    this.sixStreak = 0;
    this.sfx("miss");
    this.dice = null;
    this.movable = [];
    this.rolling = false;
    this.moving = false;
    this.hopToken = null;
    this.animatingToken = null;
    this.log(`${p.name} missed the turn (${p.misses}/3)`);
    if (p.misses >= 3) {
      p.eliminated = true;
      this.log(`${p.name} ELIMINATED (3 misses)`);
    }
    this.advanceSeat();
  }

  private advanceSeat() {
    const alive = this.players.filter(isActive).length;
    if (alive <= 1 || this.players.every((p) => !isActive(p))) {
      this.finish(alive === 1 ? "Only one player left" : "Everyone done");
      return;
    }
    let guard = 0;
    do {
      this.currentIndex = (this.currentIndex + 1) % this.players.length;
      guard++;
    } while (!isActive(this.players[this.currentIndex]) && guard < 16);
    this.turnEpoch++;
    this.turnRemaining = this.config.turnSeconds;
    this.dice = null;
    this.notify();
    void this.wait(520).then(() => this.maybeBotTurn());
  }

  private maybeBotTurn() {
    if (this.finished || !this.started) return;
    if (!this.current.isBot) return;
    void this.wait(880).then(() => {
      if (this.current.isBot && this.dice == null && !this.rolling && !this.moving) {
        void this.rollDice();
      }
    });
  }

  private botChoose(p: Player, d: number, options: number[]): number {
    if (options.length === 1) return options[0];
    if (this.config.botLevel === 1) return options[Math.floor(Math.random() * options.length)];
    const hard = this.config.botLevel >= 3;
    let bestScore = -1e9;
    let best = options[0];
    for (const idx of options) {
      const t = p.tokens[idx];
      let s = 0;
      if (!t.open) {
        s += 120;
        if (this.wouldCut(p, 0)) s += 200;
      } else {
        const np = t.pos + d;
        if (np === HOME_STEP) s += this.isRush ? 900 : 1200;
        else if (np > LAST_RING_STEP) s += 260;
        if (this.wouldCut(p, np)) s += 320 + t.pos;
        const formsBlock =
          np <= LAST_RING_STEP &&
          p.tokens.filter(
            (x) =>
              x.index !== idx &&
              x.open &&
              !x.finished &&
              x.pos <= LAST_RING_STEP &&
              ringIndexFor(p.color, x.pos) === ringIndexFor(p.color, np),
          ).length >= 1;
        if (np > LAST_RING_STEP || isSafePos(p.color, np) || formsBlock) s += 130;
        s += t.pos * (this.isRush ? 0.55 : 0.85);
        s += Math.random() * (hard ? 28 : 95);
      }
      if (s > bestScore) {
        bestScore = s;
        best = idx;
      }
    }
    return best;
  }

  private finish(reason: string) {
    if (this.finished) return;
    this.finished = true;
    if (this.ticker) clearInterval(this.ticker);
    this.log(`Match over — ${reason}`);
    const rows = this.results();
    this.sfx(rows[0]?.isMe ? "win" : "lose");
    this.notify();
  }

  results(): ScoreRow[] {
    const meId = this.me.id;
    const rows: ScoreRow[] = this.players.map((p) => ({
      name: p.realName ?? p.name,
      color: p.color,
      score: p.score,
      tokensHome: tokensHome(p),
      isMe: !p.isBot && p.id === meId,
      eliminated: p.eliminated,
      progress: p.tokens.reduce((a, t) => a + t.pos, 0),
      character: p.character,
    }));
    rows.sort((a, b) => {
      if (a.eliminated !== b.eliminated) return a.eliminated ? 1 : -1;
      if (this.isClassic) {
        const h = b.tokensHome - a.tokensHome;
        if (h !== 0) return h;
        return b.progress - a.progress;
      }
      const s = b.score - a.score;
      if (s !== 0) return s;
      return b.tokensHome - a.tokensHome;
    });
    return rows;
  }
}

export function tokenCell(p: Player, t: Token) {
  return t.open ? cellFor(p.color, t.pos) : yardSlot(p.color, t.index);
}

export function baseRect(color: PColor, size: number) {
  const o = BASE_ORIGIN[color];
  const u = size / 15;
  return { left: o.c * u, top: o.r * u, width: u * 6, height: u * 6 };
}
