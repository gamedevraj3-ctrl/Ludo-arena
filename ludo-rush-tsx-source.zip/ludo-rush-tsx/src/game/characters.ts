export interface CharacterPose {
  dx: number;
  dy: number;
  scale: number;
}

export const ROSTER = [
  "A-Patroa", "A124", "Alok", "Alvaro", "Andrew", "Antonio", "Caroline", "Cla", "Clu",
  "D-Bee", "Dasha", "Dimitri", "Ford", "Hayato", "Homer", "Ignis", "Iris", "Joseph",
  "Jota", "K", "Kapella", "Kassie", "Kelly", "Kenta", "Kiaros", "Koda", "Laura", "Leon",
  "Lila", "Luna", "Luqueta", "Maro", "Maxim", "Miguel", "Misha", "Moco", "Morse", "Nairi",
  "Nero", "Nikita", "Notora", "Olivia", "Orion", "Oscar", "Otho", "Paloma", "Rafel", "Ray",
  "Rin", "Ryden", "Santino", "Shani", "Shirou", "Skyler", "Soniya", "Steffie", "Suzy",
  "Tatsuya", "Thiva", "Wolfrah", "Wukong", "Xayne",
] as const;

export type CharacterName = (typeof ROSTER)[number];
export type CharRole = "assault" | "defense" | "support" | "special";

const ROLE_CYCLE: CharRole[] = ["assault", "defense", "support", "special"];
const ROLE_HINT: Record<string, CharRole> = {
  A124: "assault",
  Dasha: "assault",
  Iris: "assault",
  K: "special",
  Kiaros: "assault",
  Alvaro: "assault",
  Andrew: "defense",
  "D-Bee": "special",
  Homer: "special",
  Kassie: "support",
  Kelly: "support",
  Kenta: "defense",
  Lila: "support",
  Luna: "support",
  Miguel: "defense",
  Misha: "defense",
  Paloma: "support",
  Rafel: "assault",
  Santino: "defense",
  Shani: "defense",
  Skyler: "support",
  Soniya: "support",
  Steffie: "support",
  Suzy: "support",
  Tatsuya: "assault",
  Thiva: "defense",
  Wolfrah: "special",
};

export const ROLES: Record<string, CharRole> = Object.fromEntries(
  ROSTER.map((n, i) => [n, ROLE_HINT[n] ?? ROLE_CYCLE[i % 4]]),
);

export const POSES: Record<string, CharacterPose> = {};

export function poseOf(_name: string): CharacterPose {
  return { dx: 0, dy: 0, scale: 1 };
}

const ALIAS: Record<string, string> = {
  Kairos: "Kiaros",
  Rafael: "Rafel",
  Wolfrahh: "Wolfrah",
  "D-bee": "D-Bee",
};

export function resolveName(name: string): CharacterName {
  const mapped = ALIAS[name] ?? name;
  return (ROSTER.includes(mapped as CharacterName) ? mapped : "Kassie") as CharacterName;
}

export function assetFor(name: string): string {
  return `/characters/${encodeURIComponent(resolveName(name))}.png`;
}

export function pickBots(n: number, exclude?: string): string[] {
  const skip = exclude ? resolveName(exclude) : null;
  const pool = ROSTER.filter((c) => c !== skip);
  for (let i = pool.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [pool[i], pool[j]] = [pool[j], pool[i]];
  }
  return pool.slice(0, n);
}
