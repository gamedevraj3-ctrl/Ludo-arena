export type PColor = "yellow" | "blue" | "red" | "green";
export type Seat = "topLeft" | "topRight" | "bottomLeft" | "bottomRight";
export type GameMode = "bots" | "passAndPlay";
export type MatchMode = "classic" | "rush";
export type SpeedPreset = "relaxed" | "normal" | "fast";

export const SEAT_COLOR: Record<Seat, PColor> = {
  topLeft: "yellow",
  topRight: "blue",
  bottomLeft: "green",
  bottomRight: "red",
};

export const COLOR_MAIN: Record<PColor, string> = {
  yellow: "#f5b301",
  blue: "#2fa6f0",
  red: "#ef5b57",
  green: "#3ebe52",
};

export const COLOR_DARK: Record<PColor, string> = {
  yellow: "#d79600",
  blue: "#1b72c4",
  red: "#ce3a36",
  green: "#23883a",
};

export interface Token {
  index: number;
  pos: number;
  finished: boolean;
  open: boolean;
}

export interface Player {
  id: number;
  name: string;
  color: PColor;
  seat: Seat;
  isBot: boolean;
  character: string;
  realName: string | null;
  score: number;
  misses: number;
  eliminated: boolean;
  tokens: Token[];
  lastDice: number | null;
}

export function livesLeft(p: Player): number {
  return Math.max(0, Math.min(3, 3 - p.misses));
}

export function tokensHome(p: Player): number {
  return p.tokens.filter((t) => t.finished).length;
}

export function allHome(p: Player): boolean {
  return tokensHome(p) === 4;
}

export function isActive(p: Player): boolean {
  return !p.eliminated && !allHome(p);
}

export function displayName(p: Player): string {
  return p.realName ?? p.name;
}

export interface GameConfig {
  mode: GameMode;
  matchMode: MatchMode;
  playerCount: 2 | 3 | 4;
  matchSeconds: number;
  turnSeconds: number;
  myName: string;
  myCharacter: string;
  botLevel: 1 | 2 | 3;
  speed: SpeedPreset;
}

export const defaultConfig: GameConfig = {
  mode: "bots",
  matchMode: "rush",
  playerCount: 4,
  matchSeconds: 360,
  turnSeconds: 15,
  myName: "You",
  myCharacter: "Kassie",
  botLevel: 3,
  speed: "normal",
};

export interface ScoreRow {
  name: string;
  color: PColor;
  score: number;
  tokensHome: number;
  isMe: boolean;
  eliminated: boolean;
  progress: number;
  character: string;
}

export type GameSfx =
  | "matchStart"
  | "diceRoll"
  | "diceSix"
  | "hop"
  | "tokenOpen"
  | "cut"
  | "home"
  | "extraTurn"
  | "noMove"
  | "miss"
  | "forfeit"
  | "win"
  | "lose"
  | "tap";
