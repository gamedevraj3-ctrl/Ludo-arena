import type { PColor } from "./types";

export interface Cell {
  r: number;
  c: number;
}

export const RING: Cell[] = [
  { r: 6, c: 1 }, { r: 6, c: 2 }, { r: 6, c: 3 }, { r: 6, c: 4 }, { r: 6, c: 5 },
  { r: 5, c: 6 }, { r: 4, c: 6 }, { r: 3, c: 6 }, { r: 2, c: 6 }, { r: 1, c: 6 },
  { r: 0, c: 6 },
  { r: 0, c: 7 },
  { r: 0, c: 8 },
  { r: 1, c: 8 }, { r: 2, c: 8 }, { r: 3, c: 8 }, { r: 4, c: 8 }, { r: 5, c: 8 },
  { r: 6, c: 9 }, { r: 6, c: 10 }, { r: 6, c: 11 }, { r: 6, c: 12 }, { r: 6, c: 13 },
  { r: 6, c: 14 },
  { r: 7, c: 14 },
  { r: 8, c: 14 },
  { r: 8, c: 13 }, { r: 8, c: 12 }, { r: 8, c: 11 }, { r: 8, c: 10 }, { r: 8, c: 9 },
  { r: 9, c: 8 }, { r: 10, c: 8 }, { r: 11, c: 8 }, { r: 12, c: 8 }, { r: 13, c: 8 },
  { r: 14, c: 8 },
  { r: 14, c: 7 },
  { r: 14, c: 6 },
  { r: 13, c: 6 }, { r: 12, c: 6 }, { r: 11, c: 6 }, { r: 10, c: 6 }, { r: 9, c: 6 },
  { r: 8, c: 5 }, { r: 8, c: 4 }, { r: 8, c: 3 }, { r: 8, c: 2 }, { r: 8, c: 1 },
  { r: 8, c: 0 },
  { r: 7, c: 0 },
  { r: 6, c: 0 },
];

export const START_INDEX: Record<PColor, number> = {
  yellow: 0,
  blue: 13,
  red: 26,
  green: 39,
};

export const SAFE_RING = new Set([0, 13, 26, 39, 8, 21, 34, 47]);
export const STAR_RING = new Set([8, 21, 34, 47]);

export const HOME_COLUMN: Record<PColor, Cell[]> = {
  yellow: [
    { r: 7, c: 1 }, { r: 7, c: 2 }, { r: 7, c: 3 }, { r: 7, c: 4 }, { r: 7, c: 5 },
  ],
  blue: [
    { r: 1, c: 7 }, { r: 2, c: 7 }, { r: 3, c: 7 }, { r: 4, c: 7 }, { r: 5, c: 7 },
  ],
  red: [
    { r: 7, c: 13 }, { r: 7, c: 12 }, { r: 7, c: 11 }, { r: 7, c: 10 }, { r: 7, c: 9 },
  ],
  green: [
    { r: 13, c: 7 }, { r: 12, c: 7 }, { r: 11, c: 7 }, { r: 10, c: 7 }, { r: 9, c: 7 },
  ],
};

export const BASE_ORIGIN: Record<PColor, Cell> = {
  yellow: { r: 0, c: 0 },
  blue: { r: 0, c: 9 },
  green: { r: 9, c: 0 },
  red: { r: 9, c: 9 },
};

export const HOME_CENTER: Record<PColor, Cell> = {
  yellow: { r: 7, c: 6.55 },
  blue: { r: 6.55, c: 7 },
  red: { r: 7, c: 7.45 },
  green: { r: 7.45, c: 7 },
};

export const LAST_RING_STEP = 50;
export const HOME_STEP = 56;

export function yardSlot(color: PColor, slot: number): Cell {
  const o = BASE_ORIGIN[color];
  const cols = [0.35, 1.15, 1.95, 2.75];
  return { r: o.r + 0.6, c: o.c + cols[Math.max(0, Math.min(3, slot))] };
}

export function ringIndexFor(color: PColor, pos: number): number {
  return (START_INDEX[color] + pos) % 52;
}

export function cellFor(color: PColor, pos: number): Cell {
  if (pos <= LAST_RING_STEP) return RING[ringIndexFor(color, pos)];
  if (pos < HOME_STEP) return HOME_COLUMN[color][pos - 51];
  return HOME_CENTER[color];
}

export function isSafePos(color: PColor, pos: number): boolean {
  if (pos > LAST_RING_STEP) return true;
  return SAFE_RING.has(ringIndexFor(color, pos));
}

export function centerOf(cell: Cell, size: number): { x: number; y: number } {
  const u = size / 15;
  return { x: (cell.c + 0.5) * u, y: (cell.r + 0.5) * u };
}
